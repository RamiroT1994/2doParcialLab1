#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "articulo.h"
#include "Controller.h"
#include "inputs.h"
#include "parser.h"


int controller_loadFromText(char* path , LinkedList* ListaArticulos)
{
	int retorno = -1;
    FILE* pArchivo;

    int auxReturnParser;

    if(ListaArticulos != NULL && path != NULL)
    {
    	pArchivo = fopen(path,"r");

    	if(pArchivo != NULL)
    	{
    		auxReturnParser = parser_EmployeeFromText(pArchivo,ListaArticulos);

    		if(auxReturnParser == 0)
    		{
    			printf("Archivo leido correctamente");
    			retorno = 0;
    		}
    		else if(auxReturnParser == 1)
    		{
    			printf("Error al intentar leer el archivo");
    			retorno = 1;
    		}
    	}

    }

    return retorno;
}

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromBinary(char* path , LinkedList* pListEmployee)
{
	int retorno = -1;

   /*FILE* pArchivo;
   int estado = 0;

    pArchivo = fopen(path,"rb");

    if(pArchivo != NULL && pArrayListEmployee != NULL)
    {
        estado = ll_isEmpty(pArrayListEmployee);

        if(estado == 1)
        {
            retorno = parser_EmployeeFromBinary(pArchivo,pArrayListEmployee);
        }
        else
        {
            retorno = 2;
        }
    }
*/
    return retorno;
}

int controller_ListArticulos(LinkedList* listaArticulos)
{
    int retorno = -1;
    int i;
    int len;

    char auxID[] = "ID";
    char auxNombre[] = "NOMBRE";
    char auxMedida[] = "MEDIDAS";
    char auxPrecio[] = "PRECIO";
    char auxRubro[] = "RUBRO";

    eArticulo* unArticulo = NULL;

    if(listaArticulos != NULL)
    {
        len = ll_len(listaArticulos);

        printf("%s%40s%16s%10s%10s\n",auxID,auxNombre,auxMedida,auxPrecio,auxRubro);

        for(i=0; i<len; i++)
        {
            unArticulo = (eArticulo*)ll_get(listaArticulos,i);

            mostrarArticulo(unArticulo);
        }

        retorno = 1;
    }

    return retorno;
}

int controller_sortArticulos(LinkedList* listArticulos)
{
    int retorno = -1;

    if(listArticulos != NULL)
    {
    	ll_sort(listArticulos,compararPorNombre,1);

    	retorno = 1;
    }

    return retorno;
}

int controller_saveAsText(char* path , LinkedList* listaArticulos)
{
    int retorno = -1;

    FILE* pArchivo;
    eArticulo* unArticulo;

    int id;
    char articulo[50];
    char medida[50];
    float precio;
    int rubro;

    int i;
    int len;

    pArchivo = fopen(path,"w");

    if(pArchivo != NULL && listaArticulos != NULL)
    {
        len = ll_len(listaArticulos);

        fprintf(pArchivo,"%s,%s,%s,%s,%s\n","id","articulo","medida","precio","rubroid");

        for(i=0; i<len; i++)
        {
            unArticulo = (eArticulo*)ll_get(listaArticulos,i);
            articulo_getId(unArticulo,&id);
            articulo_getNombreArticulo(unArticulo,articulo);
            articulo_getMedida(unArticulo,medida);
            articulo_getPrecio(unArticulo,&precio);
            articulo_getRubro(unArticulo,&rubro);

            fprintf(pArchivo,"%d,%s,%s,%.2f,%d\n",id,articulo,medida,precio,rubro);
        }

        fclose(pArchivo);

        retorno = 1;
    }

    return retorno;
}
