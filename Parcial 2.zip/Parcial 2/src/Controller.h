/** \brief Carga una lista dinamica con datos de un archivo, en formato texto
 *
 * \param ruta del archivo
 * \param puntero a lista dinamica
 * \return -1 si puede cargar. 0 si abre archivo y carga. 1 si el puntero o lista son nulos. 2 lista ya cargada.
 *
 */
int controller_loadFromText(char* path , LinkedList* pArrayListEmployee);

/** \brief Carga una lista dinamica con datos de un archivo, en formato binario
 *
 * \param ruta del archivo
 * \param puntero a lista dinamica
 * \return -1 si puede cargar. 0 si abre archivo y carga. 1 el puntero o la lista son nulos. 2 lista ya cargada.
 *
 */
int controller_loadFromBinary(char* path , LinkedList* pArrayListEmployee);

int controller_ListArticulos(LinkedList* listaArticulos);

int controller_sortArticulos(LinkedList* listArticulos);

int controller_saveAsText(char* path , LinkedList* listaArticulos);
