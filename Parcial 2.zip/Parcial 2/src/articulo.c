/*
 * articulo.c
 *
 *  Created on: 24 jun. 2020
 *      Author: admin
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "articulo.h"
#include "LinkedList.h"

/***************** CONSTRUCTORES **********************/

eArticulo* new_articulo()
{
    eArticulo* this = (eArticulo*)malloc(sizeof(eArticulo));

    if(this != NULL)
    {
        strcpy(this->articulo,"");
        this->descuento = 0;
        this->id = 0;
        strcpy(this->medida,"");
        this->precio = 0;
        this->rubroid = 0;
    }

    return this;
}

eArticulo* new_articuloParam(int id, char* articulo, char* medida, float precio, int rubroid, float descuento)
{
	eArticulo* this = new_articulo();

	if(this != NULL && id > 0 && articulo != NULL && medida != NULL && precio > 0 && descuento > 0 && rubroid >= 1 && rubroid <= 4)
	{
		articulo_setId(this,id);
		articulo_setNombreArticulo(this,articulo);
		articulo_setMedida(this,medida);
		articulo_setPrecio(this,precio);
		articulo_setRubro(this,rubroid);
	}

	return this;

}

/********************** SETTERS ***********************/

int articulo_setId(eArticulo* this, int id)
{
	int retorno = 1;

	if( this != NULL && id > 0)
	{
		this->id = id;
		retorno = 0;
	}

	return retorno;
}

int articulo_setNombreArticulo(eArticulo* this, char* articulo)
{
	int retorno = 1;

	if(this != NULL && articulo != NULL)
	{
		strcpy(this->articulo,articulo);
		retorno = 0;
	}

	return retorno;
}

int articulo_setMedida(eArticulo* this, char* medida)
{
	int retorno = 1;

	if(this != NULL && medida != NULL)
	{
		strcpy(this->medida,medida);
		retorno = 0;
	}

	return retorno;
}

int articulo_setPrecio(eArticulo* this, float precio)
{
	int retorno = 1;

	if(this != NULL && precio > 0)
	{
		this->precio = precio;
		retorno = 0;
	}

	return retorno;
}

int articulo_setRubro(eArticulo* this, int rubroid)
{
	int retorno = 1;

	if(this != NULL && rubroid >= 1 && rubroid <= 4)
	{
		this->rubroid = rubroid;
		retorno = 0;
	}

	return retorno;
}

int articulo_setDescuento(eArticulo* this, float descuento)
{
	int retorno = 1;

	if(this != NULL && descuento > 0)
	{
		this->descuento = descuento;
		retorno = 0;
	}

	return retorno;
}

/******************** GETTERS *************************/

int articulo_getId(eArticulo* this, int* id)
{
	int retorno = 1;

	if(this != NULL && id != NULL)
	{
		*id = this->id;
		retorno = 0;
	}

	return retorno;
}

int articulo_getNombreArticulo(eArticulo* this, char* articulo)
{
	int retorno = 1;

	if(this != NULL && articulo != NULL)
	{
		strcpy(articulo,this->articulo);
		retorno = 0;
	}

	return retorno;
}

int articulo_getMedida(eArticulo* this, char* medida)
{
	int retorno = 1;

	if(this != NULL && medida != NULL)
	{
		strcpy(medida,this->medida);
		retorno = 0;
	}

	return retorno;
}

int articulo_getPrecio(eArticulo* this, float* precio)
{
	int retorno = 1;

	if(this != NULL && precio != NULL)
	{
		*precio = this->precio;
		retorno = 0;
	}

	return retorno;
}

int articulo_getRubro(eArticulo* this, int* rubro)
{
	int retorno = 1;

	if(this != NULL && rubro != NULL)
	{
		*rubro = this->rubroid;
		retorno = 0;
	}

	return retorno;
}

int articulo_getDescuento(eArticulo* this, float* descuento)
{
	int retorno = 1;

	if(this != NULL && descuento != NULL)
	{
		*descuento = this->descuento;
		retorno = 0;
	}
	return retorno;
}

void mostrarArticulo(eArticulo* articulo)
{
	char auxCadena[64];

	switch(articulo->rubroid)
	{
	case 1:
		strcpy(auxCadena,"Cuidado de ropa");
		break;
	case 2:
		strcpy(auxCadena,"Limpieza y desinfeccion");
		break;
	case 3:
		strcpy(auxCadena,"Cuidado personal e higiene");
		break;
	case 4:
		strcpy(auxCadena,"Cuidado del automotor");
		break;
	}

    if(articulo != NULL)
    {
        printf("%d%47s%10s%10.2f%23s\n", articulo->id, articulo->articulo, articulo->medida, articulo->precio,auxCadena);
    }
}

int compararPorNombre(void* a1,void* a2)
{
    int compara = -1;

    eArticulo* articulo1 = (eArticulo*)a1;
    eArticulo* articulo2 = (eArticulo*)a2;

    char n1[50];
    articulo_getNombreArticulo(articulo1,n1);
    char n2[50];
    articulo_getNombreArticulo(articulo2,n2);

    compara = strcmp(n1,n2);

    return compara;
}

void* calcularDescuento(eArticulo* articulo)
{
	float auxPrecio;
	float descuento;
	void* retorno = NULL;

	if(articulo != NULL && (articulo->rubroid == 1 || articulo->rubroid == 2))
	{
		if(articulo->rubroid == 1 && articulo->precio >= 120)
		{
			auxPrecio = articulo->precio;

			descuento = (auxPrecio * 20) / 100;

			auxPrecio = auxPrecio - descuento;

			articulo_setPrecio(articulo,auxPrecio);

			retorno = articulo;

		}

		else if(articulo->rubroid == 2 && articulo->precio <= 200)
		{
			auxPrecio = articulo->precio;

			descuento = (auxPrecio * 10) / 100;

			auxPrecio = auxPrecio - descuento;

			articulo->precio = auxPrecio;

			articulo_setPrecio(articulo,auxPrecio);

			retorno = articulo;
		}

	}

	return retorno;
}

int contarArticulos100(void* pElement)
{
	int retorno = 0;
	if(pElement != NULL)
	{
		eArticulo* auxArticulo = pElement;

		if(auxArticulo->precio > 100)
		{
			retorno = 1;
		}
	}

	return retorno;
}

int contarArticulosRubroUno(void* pElement)
{
	int retorno = 0;
	if(pElement != NULL)
	{
		eArticulo* auxArticulo = pElement;

		if(auxArticulo->rubroid == 1)
		{
			retorno = 1;
		}
	}

	return retorno;

}
