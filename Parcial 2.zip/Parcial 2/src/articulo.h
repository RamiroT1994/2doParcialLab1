/*
 * articulo.h
 *
 *  Created on: 24 jun. 2020
 *      Author: admin
 */

#ifndef ARTICULO_H_
#define ARTICULO_H_

typedef struct
{
	int id;
	char articulo[64];
	char medida[64];
	float precio;
	int rubroid;
	float descuento;

}eArticulo;


#endif /* ARTICULO_H_ */

eArticulo* new_articulo();
eArticulo* new_articuloParam(int id, char* articulo, char* medida, float precio, int rubroid, float descuento);

int articulo_setId(eArticulo* this, int id);
int articulo_setNombreArticulo(eArticulo* this, char* articulo);
int articulo_setMedida(eArticulo* this, char* medida);
int articulo_setPrecio(eArticulo* this, float precio);
int articulo_setRubro(eArticulo* this, int rubroid);
int articulo_setDescuento(eArticulo* this, float descuento);

int articulo_getId(eArticulo* this, int* id);
int articulo_getNombreArticulo(eArticulo* this, char* articulo);
int articulo_getMedida(eArticulo* this, char* medida);
int articulo_getPrecio(eArticulo* this, float* precio);
int articulo_getRubro(eArticulo* this, int* rubro);
int articulo_getDescuento(eArticulo* this, float* descuento);

int compararPorNombre(void* a1,void* a2);
void mostrarArticulo(eArticulo* articulo);
void* calcularDescuento(eArticulo* articulo);
int contarArticulos100(void* pElement);
int contarArticulosRubroUno(void* pElement);
