/*
 ============================================================================
 Name        : Parcial.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "articulo.h"
#include "inputs.h"
#include "Controller.h"

int main(void) {

	setbuf(stdout, NULL);

	int opcion;
	int auxRetorno;
	int listaCargada = -1;
	char seguir = 's';

	int cantidadMayor100 = 0;
	int cantidadRubro1 = 0;

	char path[30] = {"Datos_SP_LABO1.csv"};
	char auxPath[30];

	LinkedList* listaArticulos = ll_newLinkedList();

	do
	{

		auxRetorno = utn_getNumero(&opcion,"***************** 2DO PARCIAL DE LABORATORIO *****************\n\n1-Leer archivo de texto .csv\n2-Ordenar lista\n3-Imprimir articulos\n4-Calcular descuentos\n5-Generar archivo mapeado.csv\n6-Informe de articulos\n\n7-Salir\n\nIngrese una opcion: ","\nOpcion ingresada invalida. Reintente.\n",1,7,10);
		fflush(stdin);
		switch(opcion)
		{
			case 1:
				system("cls");

				auxRetorno = utn_getNombre(path,"Ingrese ruta de archivo (Para el ejemplo del examen el nombre del archivo sera 'Datos',\n y se concatenara automaticante la extension '.csv'): ","Cadena ingresada invalida. Reintete.\n",5);

				if(auxRetorno != -1)
				{
					strcat(path,".csv");
					listaCargada = controller_loadFromText(path,listaArticulos);
				}
				else
				{
					printf("Error en el ingreso del path\n\n");
				}
				printf("\n\n");
				system("pause");
				system("cls");
				break;
			case 2:

				if(listaCargada != -1)
				{
					auxRetorno = controller_sortArticulos(listaArticulos);

					if(auxRetorno != -1)
					{
						printf("Ordenamiento realizado con exito\n\n");
					}
					else
					{
						printf("No se ha podido realizar el ordenamiento\n\n");
					}

				}
				else
				{
					printf("Error al ordenar. No hay una lista cargada\n\n");
				}


				system("pause");
				system("cls");

				break;
			case 3:
				system("cls");
				if(listaCargada == -1)
				{
					printf("No hay un archivo de texto cargado. No se puede listar articulos\n\n");
				}
				else
				{
					auxRetorno = controller_ListArticulos(listaArticulos);
					printf("\n");
				}
				system("pause");
				system("cls");

				break;
			case 4:
				system("cls");

				if(listaCargada != -1)
				{
					ll_map(listaArticulos,calcularDescuento);
					printf("Descuentos calculados exitosamente!\n\n");
				}
				else
				{
					printf("Error al calcular descuentos. No hay una lista cargada\n\n");
				}
				system("pause");
				system("cls");
				break;
			case 5:
				auxRetorno = utn_getNombre(auxPath,"Ingrese nombre de archivo a crear (Para el examen 'mapeado'): ","Error en el ingreso del nombre",3);

				if(auxRetorno != -1)
				{
					strcat(auxPath,".csv");

					controller_saveAsText(auxPath,listaArticulos);
				}

				break;
			case 6:
				system("cls");
				cantidadMayor100 = ll_count(listaArticulos,contarArticulos100);

				if(cantidadMayor100 != -1)
				{
					printf("La cantidad de articulos mayores a 100$ es: %d\n\n", cantidadMayor100);
				}

				cantidadRubro1 = ll_count(listaArticulos,contarArticulosRubroUno);

				if(cantidadRubro1 != -1)
				{
					printf("La cantidad de articulos del rubro CUIDADO DE ROPA es: %d\n\n",cantidadRubro1);
				}

				system("pause");
				system("cls");
				break;
			case 7:
				system("pause");
				seguir = 'n';
				break;
			default:
				break;
		}

	}while(seguir == 's');

	return EXIT_SUCCESS;
}
