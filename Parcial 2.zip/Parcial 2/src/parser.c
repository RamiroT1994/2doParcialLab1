#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "articulo.h"

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_EmployeeFromText(FILE* pFile , LinkedList* pArrayListArticulos)
{
    char id[20];
    char articulo[50];
    char medida[20];
    char precio[20];
    char rubro[20];
    char descuento[20] = {"3"};
    int retorno;

    eArticulo* unArticulo = NULL;

    if(pFile != NULL && pArrayListArticulos != NULL)
    {
        fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",id,articulo,medida,precio,rubro);

        while(!feof(pFile))
        {
        	fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",id,articulo,medida,precio,rubro);

            unArticulo = new_articuloParam(atoi(id),articulo,medida,atof(precio),atoi(rubro),atof(descuento));
            ll_add(pArrayListArticulos,unArticulo);
        }

        fclose(pFile);
        retorno = 0;
    }
    else
    {
        retorno = 1;
    }

    return retorno;
}

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_EmployeeFromBinary(FILE* pFile , LinkedList* pArrayListEmployee)
{
    int retorno = -1;
/*
    Employee* empleado = NULL;

    if(pArrayListEmployee != NULL && pFile != NULL)
    {
        while(!feof(pFile))
        {
            empleado = employee_new();
            if(empleado != NULL)
            {
                fread(empleado, sizeof(Employee), 1, pFile);
                if(feof(pFile))
                {
                    retorno = -1;
                    break;
                }
                ll_add(pArrayListEmployee, empleado);
            }
        }

        fclose(pFile);

        pFile = NULL;

        retorno = 0;
    }
  */
    return retorno;
}
