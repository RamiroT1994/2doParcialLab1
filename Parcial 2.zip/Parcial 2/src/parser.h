/*
 * parser.h
 *
 *  Created on: 10 jun. 2020
 *      Author: admin
 */

#ifndef PARSER_H_
#define PARSER_H_
#endif /* PARSER_H_ */

/** \brief Carga datos desde un archivo en formato texto
 *
 * \param puntero a archivo
 * \param puntero a arraylist
 * \return retorna -1 si hay nulidad de puntero, 0 si no hay errores
 *
 */

int parser_EmployeeFromText(FILE* pFile , LinkedList* pArrayListEmployee);
/** \brief Carga datos desde un archivo en formato binario
 *
 * \param puntero a archivo
 * \param puntero a arraylist
 * \return retorna -1 si hay nulidad de puntero, 0 si no hay errores
 *
 */

int parser_EmployeeFromBinary(FILE* pFile , LinkedList* pArrayListEmployee);
